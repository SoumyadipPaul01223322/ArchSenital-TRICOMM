import { mutation } from "./_generated/server";
import { v } from "convex/values";

// Helper to determine component base vulnerability points
function calculateBaseVulnerability(nodeData: any) {
    let vulnerabilityScore = 0;
    let localFindings: string[] = [];

    // Network Vulnerabilities
    if (nodeData.exposure === "Public") {
        vulnerabilityScore += 15;
        localFindings.push("Component is publicly exposed to the internet.");
    }

    // Security Vulnerabilities
    if (nodeData.componentType === 'api') {
        if (nodeData.authType === "None") {
            vulnerabilityScore += 25;
            localFindings.push("Critical: API Endpoint lacks authentication.");
        }
        if (!nodeData.inputValidation) {
            vulnerabilityScore += 10;
            localFindings.push("API Input Validation is disabled (Injection Risk).");
        }
    }

    if (nodeData.componentType === 'db') {
        if (!nodeData.encryptionAtRest) {
            vulnerabilityScore += 15;
            localFindings.push("High: Database is missing Encryption at Rest.");
        }
        if (!nodeData.auditLoggingEnabled) {
            vulnerabilityScore += 5;
            localFindings.push("Database audit logging is disabled.");
        }
    }

    if (nodeData.encryptionInTransit === false) {
        vulnerabilityScore += 15;
        localFindings.push("Traffic to component is unencrypted (No TLS/HTTPS).");
    }

    if (nodeData.componentType === 'firewall') {
        if (nodeData.defaultPolicy === "Allow All (Insecure)") {
            vulnerabilityScore += 30;
            localFindings.push("Critical: Firewall default policy is overly permissive (Allow All).");
        }
        if (nodeData.enableIDS === false) {
            vulnerabilityScore += 10;
            localFindings.push("Firewall IDS/IPS is disabled.");
        }
    }

    // Availability
    if (nodeData.instanceCount === 1 && !nodeData.autoScaling) {
        vulnerabilityScore += 5;
        localFindings.push("Single Point of Failure: Instance count is 1 with no Auto-Scaling.");
    }

    // Impact Weighting based on Data
    const sensitivity = parseInt(nodeData.sensitivityLevel?.toString() || '1');
    const impactMultiplier = 1 + (sensitivity * 0.1); // Up to 50% multiplier for Level 5

    const finalScore = Math.round(vulnerabilityScore * impactMultiplier);

    if (sensitivity >= 4 && finalScore > 0) {
        localFindings.push(`Elevated risk modifier applied due to hosting highly sensitive data (${nodeData.dataType}).`);
    }

    return { score: finalScore, findings: localFindings, sensitivity };
}

export const simulateAttack = mutation({
    args: { diagramId: v.id("diagrams") },
    handler: async (ctx, args) => {
        const diagram = await ctx.db.get(args.diagramId);

        if (!diagram) throw new Error("Graph not found");

        const nodes = diagram.nodes;
        const edges = diagram.edges;

        // 1. Build Adjacency List for O(V+E) performance
        const adjacencyList = new Map<string, string[]>();
        nodes.forEach((node: any) => adjacencyList.set(node.id, []));

        edges.forEach((edge: any) => {
            adjacencyList.get(edge.source)?.push(edge.target);
        });

        // 2. Pre-calculate Base Vulnerabilities per Node
        const nodeMap = new Map();
        const nodeVulnerabilities = new Map();

        nodes.forEach((node: any) => {
            nodeMap.set(node.id, node);
            nodeVulnerabilities.set(node.id, calculateBaseVulnerability(node.data));
        });

        // 3. DFS Engine for Lateral Movement (Blast Radius)
        const compromised = new Set<string>();
        const visited = new Set<string>();

        // Attackers start at Public/Internet exposed nodes
        const entryPoints = nodes.filter((n: any) => n.data.exposure === "Public" || n.data.componentType === "internet");

        function isCompromisable(currentNodeId: string, sourceNodeId: string | null) {
            const vulnData = nodeVulnerabilities.get(currentNodeId);

            // If the node has a high internal vulnerability score, it falls immediately
            if (vulnData.score >= 20) return true;

            // If an attacker comes through an unencrypted connection
            if (sourceNodeId) {
                const sourceNode = nodeMap.get(sourceNodeId);
                // Simple rule: if source is compromised and current node has no strong auth, it falls laterally
                if (vulnData.score > 0) return true;
            }

            // Internet nodes are entry points and always "compromisable" from the outside
            if (nodeMap.get(currentNodeId).data.componentType === "internet") return true;

            return false;
        }

        function dfs(currentNodeId: string, sourceNodeId: string | null) {
            if (visited.has(currentNodeId)) return;
            visited.add(currentNodeId);

            if (isCompromisable(currentNodeId, sourceNodeId)) {
                compromised.add(currentNodeId);

                const neighbors = adjacencyList.get(currentNodeId) || [];
                for (const neighborId of neighbors) {
                    dfs(neighborId, currentNodeId);
                }
            }
        }

        for (const entry of entryPoints) {
            dfs(entry.id, null);
        }

        // 4. Aggregation and Compliance Mapping
        let totalSystemRisk = 0;
        const allFindings: { componentId: string, description: string, severity: 'Critical' | 'High' | 'Medium' | 'Low', complianceMappings: string[] }[] = [];

        nodes.forEach((node: any) => {
            const vuln = nodeVulnerabilities.get(node.id);
            totalSystemRisk += vuln.score;

            // Map findings to framework
            vuln.findings.forEach((f: string) => {
                let severity: 'Critical' | 'High' | 'Medium' | 'Low' = 'Medium';
                if (f.includes('Critical')) severity = 'Critical';
                else if (f.includes('High')) severity = 'High';

                allFindings.push({
                    componentId: node.id,
                    description: `[${node.data.label || node.id}] ${f}`,
                    severity,
                    complianceMappings: severity === 'Critical' ? ["SOC2 CC6.1", "OWASP A01"] : ["SOC2 CC6.6"]
                });
            });
        });

        // Multiply total risk by blast radius percentage
        const blastRadiusPercentage = compromised.size / Math.max(nodes.length, 1);
        let finalQuantifiedRisk = Math.round(totalSystemRisk * (1 + blastRadiusPercentage));

        // Scale to 0-100 logically
        if (finalQuantifiedRisk > 100) finalQuantifiedRisk = 100;
        if (nodes.length === 0) finalQuantifiedRisk = 0;

        // Update risk model in Convex DB
        await ctx.db.patch(diagram._id, { riskScore: finalQuantifiedRisk });
        await ctx.db.patch(diagram.projectId, { riskScore: finalQuantifiedRisk });

        return {
            compromisedNodes: Array.from(compromised),
            impactScore: Math.round(finalQuantifiedRisk),
            findings: allFindings
        };
    }
});
