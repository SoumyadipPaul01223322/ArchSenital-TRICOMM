"use client";

import { Suspense, useState, useCallback, useEffect, useRef } from "react";
import { useSearchParams } from "next/navigation";
import { useQuery, useMutation, useAction } from "convex/react";
import { api } from "../../../../convex/_generated/api";
import { useAuth } from "@clerk/nextjs";
import {
    ReactFlow,
    Background,
    Controls,
    MiniMap,
    addEdge,
    useNodesState,
    useEdgesState,
    applyNodeChanges,
    applyEdgeChanges,
    Node,
    Edge,
    Connection,
    OnNodesChange,
    OnEdgesChange,
    OnConnect,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import { Shield, Database, Globe, Server, Activity, Zap, ShieldAlert, Cpu, MessageSquare, Key, BarChart3, Trash2, Bot, Sparkles, Cloud, CheckCircle2 } from "lucide-react";

// Mock initial nodes to show judges right away
const initialNodes: Node[] = [
    {
        id: "internet",
        type: "default",
        position: { x: 250, y: 50 },
        data: { label: "Public Internet" },
        style: {
            background: "#000",
            color: "#fff",
            border: "1px solid #333",
            borderRadius: "8px",
            width: 150,
            padding: 10,
        }
    },
    {
        id: "lb",
        type: "default",
        position: { x: 250, y: 150 },
        data: { label: "Load Balancer" },
        style: {
            background: "#0a0a0a",
            color: "#fff",
            border: "1px solid #444",
            borderRadius: "8px",
            width: 150,
            padding: 10,
        }
    },
    {
        id: "api",
        type: "default",
        position: { x: 250, y: 250 },
        data: { label: "API Gateway" },
        style: {
            background: "#1e1b4b", // Indigo tint for logic
            color: "#fff",
            border: "1px solid #4f46e5",
            borderRadius: "8px",
            width: 150,
            padding: 10,
        }
    },
    {
        id: "db",
        type: "default",
        position: { x: 250, y: 350 },
        data: { label: "Postgres Database" },
        style: {
            background: "#2e1065", // Purple tint for data storage
            color: "#fff",
            border: "1px solid #9333ea",
            borderRadius: "8px",
            width: 150,
            padding: 10,
        }
    },
];

const initialEdges: Edge[] = [
    { id: "e1", source: "internet", target: "lb", animated: true, style: { stroke: "#fff" } },
    { id: "e2", source: "lb", target: "api", style: { stroke: "#fff" } },
    { id: "e3", source: "api", target: "db", style: { stroke: "#fff" } },
];

function ArchitectContent() {
    const searchParams = useSearchParams();
    const projectId = searchParams.get("id");
    const { orgId } = useAuth();

    // Fetch diagram from Convex
    const diagram = useQuery(api.architecture.getDiagram,
        projectId ? { projectId: projectId as any } : "skip"
    );
    const saveArch = useMutation(api.architecture.saveDiagram);
    const simulateAttack = useMutation(api.riskEngine.simulateAttack);
    const generateAiSummary = useAction(api.aiExplanation.generateExecutiveSummary);
    const provisionInfra = useAction(api.awsDeployment.provisionInfrastructure);

    const [nodes, setNodes] = useNodesState<Node>([]);
    const [edges, setEdges] = useEdgesState<Edge>([]);
    const [selectedNode, setSelectedNode] = useState<Node | null>(null);
    const [isSimulating, setIsSimulating] = useState(false);
    const [simulationResults, setSimulationResults] = useState<{
        impactScore: number;
        compromisedNodes: string[];
        findings: { componentId: string, description: string, severity: string, complianceMappings: string[] }[];
    } | null>(null);
    const [aiSummary, setAiSummary] = useState<string | null>(null);
    const [isGeneratingAi, setIsGeneratingAi] = useState(false);

    const [isDeploying, setIsDeploying] = useState(false);
    const [deploymentResults, setDeploymentResults] = useState<{
        success: boolean;
        message: string;
        resources: { componentId: string; awsService: string; resourceId: string; status: string; details: string; }[]
    } | null>(null);

    const reactFlowWrapper = useRef<HTMLDivElement>(null);

    // Construct local graph context
    useEffect(() => {
        if (diagram) {
            setNodes(diagram.nodes || []);
            setEdges(diagram.edges || []);
        } else if (diagram === null) {
            // New undefined project, use a blank slate!
            setNodes([]);
            setEdges([]);
        }
    }, [diagram, setNodes, setEdges]);

    const handleSaveAndSimulate = async () => {
        if (!projectId || !orgId) return;
        setIsSimulating(true);
        try {
            const diagramId = await saveArch({
                projectId: projectId as any,
                orgId,
                nodes,
                edges
            });

            const results = await simulateAttack({ diagramId: diagramId as any });
            setSimulationResults(results);

            // Generate AI Summary in the background
            setIsGeneratingAi(true);
            try {
                const summary = await generateAiSummary({
                    projectId: projectId as any,
                    findings: results.findings,
                    impactScore: results.impactScore
                });
                setAiSummary(summary);
            } catch (aiErr) {
                console.error("AI Generation failed:", aiErr);
                setAiSummary("Zin AI is currently unavailable. Please review the raw technical findings below.");
            } finally {
                setIsGeneratingAi(false);
            }

        } catch (err) {
            console.error(err);
            alert("Simulation engine failed to execute.");
        } finally {
            setIsSimulating(false);
        }
    };

    const handleDeployToAWS = async () => {
        if (!projectId || !orgId) return;
        setIsDeploying(true);
        try {
            // Ensure saved first
            const diagramId = await saveArch({ projectId: projectId as any, orgId, nodes, edges });

            // Trigger actual (mocked) AWS Provisioning via Convex Action
            const result = await provisionInfra({
                diagramId: diagramId as any,
                nodes: nodes
            });

            setDeploymentResults(result);

        } catch (err) {
            console.error("AWS Deployment Failed", err);
            alert("Failed to initiate AWS provisioning. Check console for details.");
        } finally {
            setIsDeploying(false);
        }
    };

    const onNodesChange: OnNodesChange = useCallback(
        (changes) => setNodes((nds) => applyNodeChanges(changes, nds)),
        [setNodes]
    );

    const onEdgesChange: OnEdgesChange = useCallback(
        (changes) => setEdges((eds) => applyEdgeChanges(changes, eds)),
        [setEdges]
    );

    const onConnect: OnConnect = useCallback(
        (connection) => setEdges((eds) => addEdge({ ...connection, animated: true, style: { stroke: '#fff' } }, eds)),
        [setEdges]
    );

    const onNodeClick = useCallback((event: React.MouseEvent, node: Node) => {
        setSelectedNode(node);
    }, []);

    const onPaneClick = useCallback(() => {
        setSelectedNode(null);
    }, []);

    const updateNodeData = useCallback((key: string, value: any) => {
        if (!selectedNode) return;

        const newData = { ...selectedNode.data, [key]: value };

        setNodes((nds) =>
            nds.map((node) => {
                if (node.id === selectedNode.id) {
                    node.data = newData;
                    setSelectedNode({ ...node }); // Update local reference for the panel
                }
                return node;
            })
        );
    }, [selectedNode, setNodes]);

    const deleteSelectedNode = useCallback(() => {
        if (!selectedNode) return;
        setNodes((nds) => nds.filter((node) => node.id !== selectedNode.id));
        setEdges((eds) => eds.filter((edge) => edge.source !== selectedNode.id && edge.target !== selectedNode.id));
        setSelectedNode(null);
    }, [selectedNode, setNodes, setEdges]);

    const onDragOver = useCallback((event: React.DragEvent) => {
        event.preventDefault();
        event.dataTransfer.dropEffect = 'move';
    }, []);

    const onDrop = useCallback(
        (event: React.DragEvent) => {
            event.preventDefault();

            const type = event.dataTransfer.getData('application/reactflow');
            const label = event.dataTransfer.getData('application/label');

            if (typeof type === 'undefined' || !type) {
                return;
            }

            // Using standard DOM getBoundingClientRect to map screen coords to Flow coords
            const reactFlowBounds = document.querySelector('.react-flow')?.getBoundingClientRect();

            if (!reactFlowBounds) return;

            const position = {
                x: event.clientX - reactFlowBounds.left,
                y: event.clientY - reactFlowBounds.top,
            };

            const newNode: Node = {
                id: `${type}-${Date.now()}`,
                type: "default",
                position,
                data: {
                    label,
                    componentType: type, // Matches schema 'type'
                    networkConfig: {},
                    securityConfig: {},
                    availabilityConfig: {},
                    dataConfig: {},
                },
                style: {
                    background: type === "internet" ? "#000" :
                        type === "firewall" ? "#3f0a0a" :
                            type === "api" ? "#1e1b4b" :
                                type === "db" ? "#2e1065" :
                                    type === "lb" ? "#0a0a0a" :
                                        "#111",
                    color: "#fff",
                    border: `1px solid ${type === "internet" ? "#333" :
                        type === "firewall" ? "#ef4444" :
                            type === "api" ? "#4f46e5" :
                                type === "db" ? "#9333ea" :
                                    type === "lb" ? "#444" :
                                        "#666"
                        }`,
                    borderRadius: "8px",
                    width: 150,
                    padding: 10,
                }
            };

            setNodes((nds) => nds.concat(newNode));
        },
        [setNodes]
    );

    const onDragStart = (event: React.DragEvent, nodeType: string, label: string) => {
        event.dataTransfer.setData('application/reactflow', nodeType);
        event.dataTransfer.setData('application/label', label);
        event.dataTransfer.effectAllowed = 'move';
    };

    return (
        <div className="flex h-[calc(100vh-8rem)] w-full border border-white/10 rounded-xl overflow-hidden shadow-2xl">

            {/* Component Palette (Left Sidebar) */}
            <div className="w-64 bg-black border-r border-white/10 p-4 flex flex-col h-full overflow-y-auto custom-scrollbar">
                <h3 className="text-sm font-semibold text-white/60 mb-4 uppercase tracking-wider">Components</h3>

                <div className="space-y-3">
                    <div
                        onDragStart={(e) => onDragStart(e, 'internet', 'Internet')} draggable
                        className="bg-white/5 border border-white/10 p-3 rounded-lg flex items-center cursor-grab hover:bg-white/10 hover:border-purple-500/30 transition-all">
                        <Globe className="h-5 w-5 mr-3 text-blue-400" />
                        <span className="text-sm font-medium">Internet / Proxy</span>
                    </div>

                    <div
                        onDragStart={(e) => onDragStart(e, 'firewall', 'Firewall')} draggable
                        className="bg-white/5 border border-white/10 p-3 rounded-lg flex items-center cursor-grab hover:bg-white/10 hover:border-purple-500/30 transition-all">
                        <Shield className="h-5 w-5 mr-3 text-red-400" />
                        <span className="text-sm font-medium">Firewall / WAF</span>
                    </div>

                    <div
                        onDragStart={(e) => onDragStart(e, 'lb', 'Load Balancer')} draggable
                        className="bg-white/5 border border-white/10 p-3 rounded-lg flex items-center cursor-grab hover:bg-white/10 hover:border-purple-500/30 transition-all">
                        <Activity className="h-5 w-5 mr-3 text-green-400" />
                        <span className="text-sm font-medium">Load Balancer</span>
                    </div>

                    <div
                        onDragStart={(e) => onDragStart(e, 'api', 'API Service')} draggable
                        className="bg-white/5 border border-white/10 p-3 rounded-lg flex items-center cursor-grab hover:bg-white/10 hover:border-purple-500/30 transition-all">
                        <Cpu className="h-5 w-5 mr-3 text-purple-400" />
                        <span className="text-sm font-medium">API Service</span>
                    </div>

                    <div
                        onDragStart={(e) => onDragStart(e, 'db', 'Database')} draggable
                        className="bg-white/5 border border-white/10 p-3 rounded-lg flex items-center cursor-grab hover:bg-white/10 hover:border-purple-500/30 transition-all">
                        <Database className="h-5 w-5 mr-3 text-yellow-400" />
                        <span className="text-sm font-medium">Database</span>
                    </div>

                    <div
                        onDragStart={(e) => onDragStart(e, 'queue', 'Message Queue')} draggable
                        className="bg-white/5 border border-white/10 p-3 rounded-lg flex items-center cursor-grab hover:bg-white/10 hover:border-purple-500/30 transition-all">
                        <MessageSquare className="h-5 w-5 mr-3 text-pink-400" />
                        <span className="text-sm font-medium">Message Queue</span>
                    </div>

                    <div
                        onDragStart={(e) => onDragStart(e, 'auth', 'Auth Service')} draggable
                        className="bg-white/5 border border-white/10 p-3 rounded-lg flex items-center cursor-grab hover:bg-white/10 hover:border-purple-500/30 transition-all">
                        <Key className="h-5 w-5 mr-3 text-orange-400" />
                        <span className="text-sm font-medium">Auth Service</span>
                    </div>

                    <div
                        onDragStart={(e) => onDragStart(e, 'monitoring', 'Monitoring')} draggable
                        className="bg-white/5 border border-white/10 p-3 rounded-lg flex items-center cursor-grab hover:bg-white/10 hover:border-purple-500/30 transition-all">
                        <BarChart3 className="h-5 w-5 mr-3 text-cyan-400" />
                        <span className="text-sm font-medium">Monitoring</span>
                    </div>
                </div>

                <div className="mt-auto pt-6">
                    <button
                        onClick={handleSaveAndSimulate}
                        disabled={isSimulating}
                        className="w-full bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white py-3 rounded-lg font-medium shadow-lg shadow-red-500/20 flex items-center justify-center transition-colors"
                    >
                        <ShieldAlert className="h-4 w-4 mr-2" />
                        {isSimulating ? "Running DFS..." : "Save & Simulate"}
                    </button>
                </div>
            </div>

            {/* Main Canvas Area */}
            <div className="flex-1 h-full bg-[#0a0a0a] relative" ref={reactFlowWrapper}>
                <ReactFlow
                    nodes={nodes}
                    edges={edges}
                    onNodesChange={onNodesChange}
                    onEdgesChange={onEdgesChange}
                    onConnect={onConnect}
                    onNodeClick={onNodeClick}
                    onPaneClick={onPaneClick}
                    onDrop={onDrop}
                    onDragOver={onDragOver}
                    fitView
                    className="bg-black/80"
                    defaultViewport={{ x: 0, y: 0, zoom: 1.5 }}
                >
                    <Background color="#333" gap={16} />
                    <Controls className="bg-white/10 border-white/20 fill-white" />
                    <MiniMap className="bg-black border border-white/10" maskColor="rgba(255, 255, 255, 0.1)" nodeColor="#666" />
                </ReactFlow>

                {/* Floating Metrics Overlay */}
                <div className="absolute top-4 left-4 right-4 flex justify-between pointer-events-none">
                    <div className="bg-black/60 backdrop-blur-md border border-white/10 px-4 py-2 rounded-lg pointer-events-auto">
                        <div className="text-xs text-white/50 uppercase tracking-widest mb-1">Total Architecture Risk</div>
                        <div className="flex items-end space-x-2">
                            <span className="text-2xl font-bold text-red-500 leading-none">85</span>
                            <span className="text-sm text-red-400 font-medium mb-0.5">Critical</span>
                        </div>
                    </div>

                    <div className="bg-black/60 backdrop-blur-md border border-white/10 px-4 py-2 rounded-lg pointer-events-auto flex items-center space-x-6">
                        <div>
                            <div className="text-xs text-white/50 mb-1">Nodes</div>
                            <div className="font-semibold text-white/90">4</div>
                        </div>
                        <div>
                            <div className="text-xs text-white/50 mb-1">State</div>
                            <div className="font-semibold text-green-400 flex items-center">
                                <span className="h-2 w-2 rounded-full bg-green-400 mr-2"></span>
                                Saved
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Configuration Right Panel - Sliding Entry */}
            <div className={`w-80 bg-black border-l border-white/10 flex flex-col transition-all duration-300 ${selectedNode ? 'translate-x-0' : 'translate-x-full hidden'}`}>
                <div className="p-4 border-b border-white/10 bg-white/5 flex items-start justify-between">
                    <div>
                        <h3 className="font-semibold text-lg">{selectedNode?.data.label as string || "Component config"}</h3>
                        <p className="text-sm text-white/50">ID: {selectedNode?.id}</p>
                    </div>
                    <button
                        onClick={deleteSelectedNode}
                        className="p-2 hover:bg-red-500/20 text-white/50 hover:text-red-400 rounded-lg transition-colors border border-transparent hover:border-red-500/30"
                        title="Delete Component">
                        <Trash2 className="h-4 w-4" />
                    </button>
                </div>

                <div className="flex-1 overflow-y-auto p-4 space-y-6">

                    {/* Detailed Component Configurations */}
                    <div className="space-y-6">

                        {/* 1. Network Configuration */}
                        <div className="space-y-3">
                            <h4 className="text-xs font-semibold uppercase text-cyan-400 tracking-wider flex items-center border-b border-white/10 pb-2">
                                <Globe className="h-3 w-3 mr-2" /> Network Configuration
                            </h4>
                            <div className="space-y-3 pt-1">
                                {(selectedNode?.data?.componentType !== 'auth' && selectedNode?.data?.componentType !== 'monitoring') && (
                                    <>
                                        <label className="text-sm text-white/70">Exposure</label>
                                        <select
                                            value={selectedNode?.data?.exposure as string || "Private"}
                                            onChange={(e) => updateNodeData("exposure", e.target.value)}
                                            className="w-full bg-black/50 border border-white/10 rounded-lg p-2 text-sm focus:outline-none focus:border-cyan-500 transition-colors"
                                        >
                                            <option value="Public">Public / Internet Facing</option>
                                            <option value="Private">Private Subnet</option>
                                            <option value="Internal VPC">Internal VPC Only</option>
                                        </select>
                                    </>
                                )}
                                <label className="text-sm text-white/70">Allowed IP Range</label>
                                <input
                                    type="text"
                                    value={selectedNode?.data?.ipRange as string || "0.0.0.0/0"}
                                    onChange={(e) => updateNodeData("ipRange", e.target.value)}
                                    className="w-full bg-black/50 border border-white/10 rounded-lg p-2 text-sm focus:outline-none focus:border-cyan-500 transition-colors placeholder:text-white/20"
                                    placeholder="e.g. 10.0.0.0/16"
                                />
                                {selectedNode?.data?.componentType === 'firewall' && (
                                    <>
                                        <label className="text-sm text-white/70 mt-2">Default Policy</label>
                                        <select
                                            value={selectedNode?.data?.defaultPolicy as string || "Deny All (Secure)"}
                                            onChange={(e) => updateNodeData("defaultPolicy", e.target.value)}
                                            className="w-full bg-black/50 border border-white/10 rounded-lg p-2 text-sm focus:outline-none focus:border-cyan-500 transition-colors">
                                            <option value="Deny All (Secure)">Deny All (Secure)</option>
                                            <option value="Allow All (Insecure)">Allow All (Insecure)</option>
                                        </select>
                                    </>
                                )}
                            </div>
                        </div>

                        {/* 2. Security Configuration */}
                        <div className="space-y-3">
                            <h4 className="text-xs font-semibold uppercase text-cyan-400 tracking-wider flex items-center border-b border-white/10 pb-2">
                                <Shield className="h-3 w-3 mr-2" /> Security Controls
                            </h4>
                            <div className="space-y-3 pt-1">
                                {selectedNode?.data?.componentType === 'api' && (
                                    <>
                                        <label className="text-sm text-white/70">Authentication Type</label>
                                        <select
                                            value={selectedNode?.data?.authType as string || "JWT"}
                                            onChange={(e) => updateNodeData("authType", e.target.value)}
                                            className="w-full bg-black/50 border border-white/10 rounded-lg p-2 text-sm focus:outline-none focus:border-cyan-500 transition-colors">
                                            <option value="JWT">JWT</option>
                                            <option value="OAuth2">OAuth2</option>
                                            <option value="APIKey">API Key</option>
                                            <option value="Internal">Internal Auth</option>
                                            <option value="None">None (Public)</option>
                                        </select>
                                        <label className="flex items-center space-x-3 cursor-pointer mt-2">
                                            <input type="checkbox"
                                                checked={(selectedNode?.data?.inputValidation as boolean) ?? true}
                                                onChange={(e) => updateNodeData("inputValidation", e.target.checked)}
                                                className="form-checkbox bg-black border-white/20 text-cyan-500 rounded focus:ring-cyan-500" />
                                            <span className="text-sm text-white/80">Input Validation enabled</span>
                                        </label>
                                    </>
                                )}

                                {selectedNode?.data?.componentType === 'db' && (
                                    <>
                                        <label className="flex items-center space-x-3 cursor-pointer">
                                            <input type="checkbox"
                                                checked={(selectedNode?.data?.encryptionAtRest as boolean) ?? false}
                                                onChange={(e) => updateNodeData("encryptionAtRest", e.target.checked)}
                                                className="form-checkbox bg-black border-white/20 text-cyan-500 rounded focus:ring-cyan-500" />
                                            <span className="text-sm text-white/80">Encryption at Rest (KMS)</span>
                                        </label>
                                        <label className="flex items-center space-x-3 cursor-pointer">
                                            <input type="checkbox"
                                                checked={(selectedNode?.data?.auditLoggingEnabled as boolean) ?? false}
                                                onChange={(e) => updateNodeData("auditLoggingEnabled", e.target.checked)}
                                                className="form-checkbox bg-black border-white/20 text-cyan-500 rounded focus:ring-cyan-500" />
                                            <span className="text-sm text-white/80">Audit Logging Enabled</span>
                                        </label>
                                    </>
                                )}

                                <label className="flex items-center space-x-3 cursor-pointer mt-2">
                                    <input type="checkbox"
                                        checked={(selectedNode?.data?.encryptionInTransit as boolean) ?? true}
                                        onChange={(e) => updateNodeData("encryptionInTransit", e.target.checked)}
                                        className="form-checkbox bg-black border-white/20 text-cyan-500 rounded focus:ring-cyan-500" />
                                    <span className="text-sm text-white/80">Require TLS/HTTPS</span>
                                </label>
                            </div>
                        </div>

                        {/* 3. Availability Configuration */}
                        <div className="space-y-3">
                            <h4 className="text-xs font-semibold uppercase text-cyan-400 tracking-wider flex items-center border-b border-white/10 pb-2">
                                <Activity className="h-3 w-3 mr-2" /> Availability & Compute
                            </h4>
                            <div className="space-y-3 pt-1">
                                <div className="flex items-center justify-between">
                                    <label className="text-sm text-white/70">Instance Count</label>
                                    <input
                                        type="number"
                                        min="1"
                                        max="100"
                                        value={selectedNode?.data?.instanceCount as number || 1}
                                        onChange={(e) => updateNodeData("instanceCount", parseInt(e.target.value))}
                                        className="w-20 bg-black/50 border border-white/10 rounded-lg p-1.5 text-sm text-center focus:outline-none focus:border-cyan-500 transition-colors text-white"
                                    />
                                </div>

                                <label className="flex items-center space-x-3 cursor-pointer">
                                    <input type="checkbox"
                                        checked={(selectedNode?.data?.autoScaling as boolean) ?? false}
                                        onChange={(e) => updateNodeData("autoScaling", e.target.checked)}
                                        className="form-checkbox bg-black border-white/20 text-cyan-500 rounded focus:ring-cyan-500" />
                                    <span className="text-sm text-white/80">Auto-Scaling Enabled</span>
                                </label>

                                {(selectedNode?.data?.componentType === 'db' || selectedNode?.data?.componentType === 'queue') && (
                                    <label className="flex items-center space-x-3 cursor-pointer">
                                        <input type="checkbox"
                                            checked={(selectedNode?.data?.automatedBackups as boolean) ?? true}
                                            onChange={(e) => updateNodeData("automatedBackups", e.target.checked)}
                                            className="form-checkbox bg-black border-white/20 text-cyan-500 rounded focus:ring-cyan-500" />
                                        <span className="text-sm text-white/80">Automated Daily Backups</span>
                                    </label>
                                )}
                            </div>
                        </div>

                        {/* 4. Data Configuration */}
                        <div className="space-y-3">
                            <h4 className="text-xs font-semibold uppercase text-cyan-400 tracking-wider flex items-center border-b border-white/10 pb-2">
                                <Database className="h-3 w-3 mr-2" /> Data Classification
                            </h4>
                            <div className="space-y-3 pt-1">
                                <label className="text-sm text-white/70">Data Type</label>
                                <select
                                    value={selectedNode?.data?.dataType as string || "Internal"}
                                    onChange={(e) => updateNodeData("dataType", e.target.value)}
                                    className="w-full bg-black/50 border border-white/10 rounded-lg p-2 text-sm focus:outline-none focus:border-cyan-500 transition-colors">
                                    <option value="Public">Public Data</option>
                                    <option value="Internal">Internal (Company Only)</option>
                                    <option value="Confidential">Confidential</option>
                                    <option value="PII">PII (Personal Info)</option>
                                    <option value="Financial">Financial / PCI</option>
                                </select>

                                <div>
                                    <div className="flex justify-between mb-1">
                                        <label className="text-sm text-white/70">Sensitivity Level (1-5)</label>
                                        <span className="text-xs text-cyan-400 font-bold bg-cyan-500/10 border border-cyan-500/20 px-2 py-0.5 rounded">{selectedNode?.data?.sensitivityLevel as number || 1}</span>
                                    </div>
                                    <input
                                        type="range"
                                        min="1"
                                        max="5"
                                        step="1"
                                        value={selectedNode?.data?.sensitivityLevel as number || 1}
                                        onChange={(e) => updateNodeData("sensitivityLevel", parseInt(e.target.value))}
                                        className="w-full h-1 bg-white/20 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                                    />
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>

            {/* Compliance & Threat Report Overlay */}
            {simulationResults && (
                <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 md:p-8 animate-in fade-in duration-300">
                    <div className="bg-black border border-white/10 rounded-2xl w-full max-w-5xl max-h-full flex flex-col shadow-2xl relative overflow-hidden">

                        {/* Header */}
                        <div className="p-6 border-b border-white/10 bg-white/5 flex items-center justify-between sticky top-0 z-10">
                            <div className="flex items-center space-x-4">
                                <div className="p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/20">
                                    <ShieldAlert className="h-6 w-6 text-cyan-400" />
                                </div>
                                <div>
                                    <h2 className="text-xl font-bold text-white tracking-tight">Enterprise Threat Analysis Report</h2>
                                    <p className="text-sm text-white/50">Mathematical validation of architecture controls and attack simulation</p>
                                </div>
                            </div>
                            <div className="flex items-center space-x-4">
                                <div className="text-right">
                                    <div className="text-xs text-white/50 uppercase tracking-wider mb-1">Exposure Index</div>
                                    <div className={`text-2xl font-bold ${simulationResults.impactScore > 70 ? 'text-red-500' : simulationResults.impactScore > 30 ? 'text-yellow-500' : 'text-cyan-500'}`}>
                                        {simulationResults.impactScore} <span className="text-sm font-medium opacity-50">/100</span>
                                    </div>
                                </div>
                                <button
                                    onClick={() => setSimulationResults(null)}
                                    className="p-2 hover:bg-white/10 text-white/50 hover:text-white rounded-lg transition-colors border border-transparent hover:border-white/20"
                                >
                                    ✕
                                </button>
                            </div>
                        </div>

                        {/* Findings Content */}
                        <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">

                            {/* Zing AI Executive Summary Card */}
                            <div className="mb-8 p-1 rounded-2xl bg-gradient-to-r from-cyan-500/20 via-purple-500/20 to-transparent">
                                <div className="bg-black/80 backdrop-blur-xl border border-white/5 rounded-xl p-6">
                                    <div className="flex items-center space-x-3 mb-4">
                                        <div className="p-2 rounded-lg bg-cyan-500/10">
                                            <Sparkles className="h-5 w-5 text-cyan-400" />
                                        </div>
                                        <h3 className="text-lg font-semibold text-white flex items-center">
                                            Zin AI Executive Summary
                                        </h3>
                                    </div>

                                    {isGeneratingAi ? (
                                        <div className="flex items-center space-x-3 text-white/50 py-4">
                                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-cyan-500"></div>
                                            <span className="text-sm">Zin AI is analyzing the threat graph and generating an executive brief...</span>
                                        </div>
                                    ) : (
                                        <div className="prose prose-invert max-w-none text-white/80 text-sm leading-relaxed whitespace-pre-wrap">
                                            {aiSummary}
                                        </div>
                                    )}
                                </div>
                            </div>

                            {/* Summary Stats */}
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                                <div className="bg-white/5 border border-white/10 rounded-xl p-4">
                                    <div className="text-xs text-white/40 uppercase tracking-wider mb-2">Compromised Nodes</div>
                                    <div className="text-3xl font-light">{simulationResults.compromisedNodes.length}</div>
                                </div>
                                <div className="bg-white/5 border border-white/10 rounded-xl p-4">
                                    <div className="text-xs text-white/40 uppercase tracking-wider mb-2">Critical Findings</div>
                                    <div className="text-3xl font-light text-red-500">{simulationResults.findings.filter(f => f.severity === 'Critical').length}</div>
                                </div>
                                <div className="bg-white/5 border border-white/10 rounded-xl p-4">
                                    <div className="text-xs text-white/40 uppercase tracking-wider mb-2">Compliance Violations</div>
                                    <div className="text-3xl font-light text-yellow-500">{simulationResults.findings.filter(f => f.complianceMappings.length > 0).length}</div>
                                </div>
                            </div>

                            {/* Detailed Findings Table */}
                            <h3 className="text-sm font-semibold uppercase text-cyan-400 tracking-wider mb-4 border-b border-white/10 pb-2 flex items-center">
                                <Activity className="h-4 w-4 mr-2" /> Threat Vectors & Violations
                            </h3>

                            {simulationResults.findings.length === 0 ? (
                                <div className="text-center py-12 bg-white/5 rounded-xl border border-white/10 border-dashed">
                                    <Shield className="h-12 w-12 text-cyan-500/50 mx-auto mb-4" />
                                    <p className="text-white font-medium">Zero Critical Exposures Detected</p>
                                    <p className="text-sm text-white/50">Your architecture aligns with core compliance frameworks.</p>
                                </div>
                            ) : (
                                <div className="space-y-3">
                                    {simulationResults.findings.map((finding, idx) => (
                                        <div key={idx} className="bg-black/50 border border-white/10 rounded-xl p-4 flex flex-col md:flex-row md:items-start justify-between gap-4">
                                            <div className="flex items-start space-x-3">
                                                <div className={`mt-1 h-2 w-2 rounded-full ${finding.severity === 'Critical' ? 'bg-red-500 animate-pulse' : finding.severity === 'High' ? 'bg-orange-500' : 'bg-yellow-500'}`}></div>
                                                <div>
                                                    <p className="text-white/90 text-sm font-medium">{finding.description}</p>
                                                    <div className="flex space-x-2 mt-2">
                                                        {finding.complianceMappings.map((mapping, mapIdx) => (
                                                            <span key={mapIdx} className="text-[10px] uppercase font-bold text-white/40 bg-white/5 px-2 py-0.5 rounded border border-white/10">
                                                                {mapping}
                                                            </span>
                                                        ))}
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="flex-shrink-0">
                                                <span className={`text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full border ${finding.severity === 'Critical' ? 'bg-red-500/10 text-red-400 border-red-500/20' : finding.severity === 'High' ? 'bg-orange-500/10 text-orange-400 border-orange-500/20' : 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20'}`}>
                                                    {finding.severity}
                                                </span>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}

                        </div>
                    </div>
                </div>
            )}


            {/* AWS Deployment Results Overlay */}
            {
                deploymentResults && (
                    <div className="absolute inset-0 z-[60] flex items-center justify-center bg-black/90 backdrop-blur-md p-4 md:p-8 animate-in fade-in zoom-in-95 duration-300">
                        <div className="bg-[#111] border border-orange-500/30 rounded-2xl w-full max-w-4xl max-h-full flex flex-col shadow-[0_0_100px_rgba(249,115,22,0.15)] relative overflow-hidden">

                            {/* Header */}
                            <div className="p-6 border-b border-white/10 bg-gradient-to-r from-orange-500/10 to-transparent flex items-center justify-between sticky top-0 z-10">
                                <div className="flex items-center space-x-4">
                                    <div className="p-3 rounded-xl bg-orange-500/20 border border-orange-500/30">
                                        <Cloud className="h-6 w-6 text-orange-400" />
                                    </div>
                                    <div>
                                        <h2 className="text-xl font-bold text-white tracking-tight">AWS Infrastructure Provisioned</h2>
                                        <p className="text-sm text-orange-200/50">Infrastructure-as-Code execution completed successfully.</p>
                                    </div>
                                </div>
                                <button
                                    onClick={() => setDeploymentResults(null)}
                                    className="p-2 hover:bg-white/10 text-white/50 hover:text-white rounded-lg transition-colors border border-transparent hover:border-white/20"
                                >
                                    ✕
                                </button>
                            </div>

                            {/* Resources Table */}
                            <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
                                <div className="space-y-4">
                                    {deploymentResults.resources.map((res, idx) => (
                                        <div key={idx} className="bg-black/50 border border-white/5 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-white/[0.02] transition-colors">
                                            <div className="flex items-start space-x-4">
                                                <div className="mt-1">
                                                    {res.awsService === 'EC2' ? <Server className="h-5 w-5 text-blue-400" /> :
                                                        res.awsService === 'RDS' ? <Database className="h-5 w-5 text-purple-400" /> :
                                                            <Globe className="h-5 w-5 text-gray-400" />}
                                                </div>
                                                <div>
                                                    <div className="flex items-center space-x-2">
                                                        <span className="text-white font-medium">{res.awsService} Resources</span>
                                                        <span className="text-xs text-white/40 bg-white/10 px-2 py-0.5 rounded font-mono">{res.resourceId}</span>
                                                    </div>
                                                    <p className="text-sm text-white/60 mt-1">{res.details}</p>
                                                </div>
                                            </div>
                                            <div className="flex items-center space-x-2 self-start md:self-auto bg-emerald-500/10 border border-emerald-500/20 px-3 py-1 rounded-full">
                                                <CheckCircle2 className="h-3 w-3 text-emerald-400" />
                                                <span className="text-xs uppercase font-bold text-emerald-400 tracking-wider">
                                                    {res.status}
                                                </span>
                                            </div>
                                        </div>
                                    ))}

                                    {deploymentResults.resources.length === 0 && (
                                        <div className="text-center py-12 text-white/50">
                                            No AWS resources were provisioned. Ensure your architecture has compute or database nodes.
                                        </div>
                                    )}
                                </div>
                            </div>

                        </div>
                    </div>
                )
            }
        </div >
    );
}

export default function ArchitectPage() {
    return (
        <Suspense fallback={
            <div className="flex h-[calc(100vh-8rem)] w-full items-center justify-center border border-white/10 rounded-xl bg-black shadow-2xl">
                <div className="flex flex-col items-center">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500 mb-4"></div>
                    <p className="text-white/50 text-sm">Loading architecture workspace...</p>
                </div>
            </div>
        }>
            <ArchitectContent />
        </Suspense>
    );
}
